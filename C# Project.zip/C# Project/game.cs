using System;

namespace NumberGuessingGame
{
    class NumberGuessingGame
    {
        private int minValue;                   // Minimum value for the secret number
        private int maxValue;                   // Maximum value for the secret number
        private int secretNumber;               // The secret number to guess
        private int guesses;                    // Total Number of guesses made
        private int[] guessHistory;             // Array for storing guess history
        private Random random;                  // Random number generator

        public NumberGuessingGame(int minValue, int maxValue)
        {
            this.minValue = minValue;
            this.maxValue = maxValue;
            this.random = new Random();
            this.secretNumber = this.random.Next(minValue, maxValue + 1); // Generate random secret number
            this.guesses = 0;
            this.guessHistory = new int[maxValue - minValue + 1]; // Initialize guess history array
        }

        public void Play()
        {
            bool playAgain = true;
            string response;

            while (playAgain)
            {
                Console.WriteLine($"Guess a number between {minValue} - {maxValue}: ");

                for (int i = 0; i < guessHistory.Length; i++)
                {
                    guessHistory[i] = -1; // Initialize the guess history array with -1
                }

                do
                {
                    int guess;
                    string input = GetValidInput(); // Use the static method to get valid input
                    if (int.TryParse(input, out guess))
                    {
                        Console.WriteLine($"Guess: {guess}");

                        if (guess > secretNumber)
                        {
                            Console.WriteLine($"{guess} is high!");
                        }
                        else if (guess < secretNumber)
                        {
                            Console.WriteLine($"{guess} is low!");
                        }

                        guesses++;

                        // Add the guess to the guess history array
                        for (int i = 0; i < guessHistory.Length; i++)
                        {
                            if (guessHistory[i] == -1)
                            {
                                guessHistory[i] = guess;
                                break;
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input! Please enter a valid integer.");
                    }
                } while (guesses <= 10 && secretNumber != guessHistory[guesses - 1]);
                 
                if (secretNumber == guessHistory[guesses - 1])
                {
                    Console.WriteLine($"Number to be guessed: {secretNumber}");
                    Console.WriteLine("YOU WIN!");
                }
                else
                {
                    Console.WriteLine($"Number to be guessed: {secretNumber}");
                    Console.WriteLine("GAME OVER! You reached the maximum number of guesses.");
                }

                // Displaying the guess history after the user reaches the maximum number of wrong guesses

                Console.WriteLine($"Number of Guesses: {guesses}");
                Console.WriteLine("Guess History: ");
                for (int i = 0; i < guessHistory.Length; i++)
                {
                    if (guessHistory[i] != -1)
                    {
                        Console.Write($"{guessHistory[i]} ");
                    }
                }
                Console.WriteLine();

                // Asking user if they want to continue playing or exit

                Console.WriteLine("Would you like to play again? (Y/N): ");
                response = Console.ReadLine();
                response = response.ToUpper();

                switch (response)
                {
                    case "Y":
                        playAgain = true;
                        ResetGame();
                        break;
                    default:
                        playAgain = false;
                        break;
                }
            }

            Console.WriteLine("Thanks for playing! Have a Nice Day!");

            Console.ReadKey();
        }

        private void ResetGame()
        {
            this.secretNumber = this.random.Next(minValue, maxValue + 1); // Generate new random secret number
            this.guesses = 0; // Reset guesses counter
            this.guessHistory = new int[maxValue - minValue + 1];
        }
        // Exception Handling
        private static string GetValidInput()
        {
            string input = Console.ReadLine();
            int parsedValue;
            while (!int.TryParse(input, out parsedValue))
            {
                Console.WriteLine("Invalid input! Please enter a valid integer.");
                input = Console.ReadLine();
            }
            return input;
        }
    }
}

//END OF CODE