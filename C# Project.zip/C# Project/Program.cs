﻿using System;

namespace NumberGuessingGame
{
 class Program
    {
        static void Main(string[] args)
        {
            int minValue = 1;
            int maxValue = 100;
            NumberGuessingGame game = new NumberGuessingGame(minValue, maxValue);
            game.Play();
        }
    }
}
